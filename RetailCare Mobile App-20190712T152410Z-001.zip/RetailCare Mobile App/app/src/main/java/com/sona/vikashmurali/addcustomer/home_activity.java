package com.sona.vikashmurali.addcustomer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class home_activity extends AppCompatActivity {
    Button search,addcust,analyze;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_activity);

        search=(Button)findViewById(R.id.search_activity);
        addcust=(Button)findViewById(R.id.addcustomer);
        analyze=(Button) findViewById(R.id.analyze);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(), Search.class);

                startActivity(intent);
                //finish();

            }
        });
        analyze.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(), analysis.class);

                startActivity(intent);
            }
        });

        addcust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),insert.class);
                startActivity(intent);
            }
        });
    }
}
