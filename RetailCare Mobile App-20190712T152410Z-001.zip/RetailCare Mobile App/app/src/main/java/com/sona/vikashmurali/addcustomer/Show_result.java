package com.sona.vikashmurali.addcustomer;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class Show_result extends AppCompatActivity {
    String job_str,marital_str,education_str,defaultt_str,housign_str,loan_str,contact_str,month_str,poutcome_str;
    int day_flot,duration_flot,pdays_flot,campaign_flot,previous_flot,age_double,balance_double;
    String data_from_db,sresult;
    Button predict;
    TextView result,show_data;
    int housing_int,loan_int;
     String URL ="http://192.168.1.102:8080/bank/insert.php?";
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_result);

        predict=(Button)findViewById(R.id.search_activity);
        result=(TextView)findViewById(R.id.result);
        show_data=(TextView)findViewById(R.id.show_data);

        Intent intent=getIntent();
        age_double=intent.getIntExtra("age",0);
        job_str=intent.getStringExtra("job");
        marital_str=intent.getStringExtra("marital");
        education_str=intent.getStringExtra("education");
        defaultt_str=intent.getStringExtra("defaultt");
        balance_double=intent.getIntExtra("balance",0);
        housign_str=intent.getStringExtra("housing");
        loan_str=intent.getStringExtra("loan");
        contact_str=intent.getStringExtra("contact");
        day_flot=intent.getIntExtra("day",0);
        month_str=intent.getStringExtra("month");
        duration_flot=intent.getIntExtra("duration",0);
        campaign_flot=intent.getIntExtra("campaign",0);
        pdays_flot=intent.getIntExtra("pdays",0);
        previous_flot=intent.getIntExtra("previous",0);
        poutcome_str=intent.getStringExtra("poutcome");

        if(housign_str.equalsIgnoreCase("yes")){
            housing_int=1;
        }
        else if(housign_str.equalsIgnoreCase("no")){housing_int=0;}

        if(loan_str.equalsIgnoreCase("yes")){loan_int=1;}
        else if(loan_str.equalsIgnoreCase("no")){loan_int=0;}

        System.out.println("intent received");
        System.out.println(age_double+job_str+marital_str+education_str+defaultt_str+balance_double+housign_str+loan_str+contact_str+day_flot+month_str+duration_flot+campaign_flot+pdays_flot+previous_flot+poutcome_str);
        String data=age_double+job_str+marital_str+education_str+defaultt_str+balance_double+housign_str+loan_str+contact_str+day_flot+month_str+duration_flot+campaign_flot+pdays_flot+previous_flot+poutcome_str;

        String data1="Age:"+age_double+"\n"+"Job:"+job_str+"\n"+"Marital Status:"+marital_str+"\n"+"Education:"+education_str+"\n"+"Credit card:"+defaultt_str+"\n"+"Balance:"+balance_double+"\n"+"Housing loan:"+housign_str+"\n"+"Loan:"+loan_str+"\n"+"Contact:"+contact_str+"\n"+"Contacted day:"+day_flot+"\n"+"Contacted Month:"+month_str+"\n"+"Last call duration(sec):"+duration_flot+"\n"+"No of contact:"+campaign_flot+"\n"+"Last contacted:"+pdays_flot+"\n"+"# of previously contact:"+previous_flot+"\n"+"Previous Campaign result:"+poutcome_str+"\n\n";

        show_data.setText(data1);
        predict.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d d1=new d();
               d1.execute();
            }
        });

    }

   public class d extends AsyncTask<Void,Void,Void> {
        private Context context;


        @RequiresApi(api = Build.VERSION_CODES.O)
        @Override
        protected Void doInBackground(Void... voids) {
            Log.e("start","do in back");

            try {
                String url = "https://tamchikki.eu-gb.mybluemix.net/send?balance="+balance_double+"&housing="+housing_int+"&loan="+loan_int+"&day="+day_flot+"&duration="+duration_flot+"&campaign="+campaign_flot+"&pdays="+pdays_flot+"&Previous="+previous_flot;
                //String url = "https://tamchikki.eu-gb.mybluemix.net/send?balance="+143+"&housing=yes"+"&loan=no"+"&day="+1+"&duration="+1+"&campaign="+1+"&pdays="+1+"&Previous="+1;
                System.out.println("URL: " + url);
                URL obj = new URL(url);
                HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
                con.setRequestMethod("GET");

                Log.e("start","");

                int responseCode = con.getResponseCode();
                System.out.println("\nSending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                //print result
                System.out.println(response.toString());
                sresult = response.toString();
                System.out.println(sresult);


                con.disconnect();

            } catch (IOException ioe) {
                ioe.printStackTrace();

                System.out.println(ioe.toString());
            }


            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            System.out.println("pre execute");
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            System.out.println("post execute");
            showreport();
            sendtodb();
        }
    }

    private void sendtodb() {
        String data="";
        data+="job="+job_str;
        data+="&age="+age_double;
        data+="&marital="+marital_str;
        data+="&education="+education_str;
        data+="&_default="+defaultt_str;
        data+="&balance="+balance_double;
        data+="&housing="+housign_str;
        data+="&loan="+loan_str;
        data+="&contact="+contact_str;
        data+="&day="+day_flot;
        data+="&month="+month_str;
        data+="&duration="+duration_flot;
        data+="&campaign="+campaign_flot;
        data+="&pdays="+pdays_flot;
        data+="&previous="+previous_flot;
        data+="&poutcome="+poutcome_str;
        data+="&deposit="+sresult;

        System.out.println("starting url is  "+URL);
        URL+=data;
        System.out.println("added url is  "+URL);

        StringRequest stringRequest=new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    //Toast.makeText(getApplicationContext(),"response try"+response.toString(),Toast.LENGTH_SHORT).show();
                    JSONObject jsonObject=new JSONObject(response);
                    String message=jsonObject.getString("message");
                    boolean error=jsonObject.getBoolean("error");
                    if(!error){
                        //cid=jsonObject.getInt("cid");

                        //sp =getSharedPreferences("user",MODE_PRIVATE);
                        //SharedPreferences.Editor et=sp.edit();
                        //et.putInt("cid",cid);
                        //et.commit();
                        //progressBar.setVisibility(View.GONE);


                    }
                    else {
                        // progressBar.setVisibility(View.GONE);
                        Toast.makeText(getApplicationContext(),""+message.toString(),Toast.LENGTH_LONG).show();
                        return;
                    }

                } catch (JSONException e) {
                    //progressBar.setVisibility(View.GONE);
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(),"error"+e.toString(),Toast.LENGTH_SHORT).show();
                    return;
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),""+error.toString(),Toast.LENGTH_LONG).show();
            }
        });
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


        URL ="http://192.168.1.102:8080/bank/insert.php?";
    }

    private void showreport() {
        System.out.println("show report");
        if(sresult.equalsIgnoreCase("yes"))
        {result.setTextColor(getResources().getColor(R.color.green));
        result.setText("Yes");
        }
        else if(sresult.equalsIgnoreCase("no"))
        {
            result.setTextColor(getResources().getColor(R.color.red));
            result.setText("No");
        }
        //result.setText(sresult.toString());

        //onBackPressed();
    }

    @Override
    public void onBackPressed() {

        //
        Intent intent = new Intent(Show_result.this, home_activity.class);
        startActivity(intent);
        finish();
    }
}
