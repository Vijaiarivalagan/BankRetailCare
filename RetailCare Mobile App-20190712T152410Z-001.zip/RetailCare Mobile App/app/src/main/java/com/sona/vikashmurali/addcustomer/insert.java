package com.sona.vikashmurali.addcustomer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class insert extends AppCompatActivity {
Button nxt;
    EditText age,balance;
    String job_str,marital_str,education_str,defaultt_str,housign_str,loan_str,contact_str,balance_str,age_str;
    Spinner job_spinner,marital_spinner,education_spinner,defaultt_spinner,housing_spinner,loan_spinner,contact_spinner;
    Button next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);
        Log.d("log 1","starting app-----");

        age=(EditText)findViewById(R.id.age);
        balance=(EditText)findViewById(R.id.balance);
        job_spinner=(Spinner)findViewById(R.id.job);
        marital_spinner=(Spinner)findViewById(R.id.marital);
        education_spinner=(Spinner)findViewById(R.id.education);
        defaultt_spinner=(Spinner)findViewById(R.id.defaultt);
        housing_spinner=(Spinner)findViewById(R.id.housing);
        loan_spinner=(Spinner)findViewById(R.id.loan);
        contact_spinner=(Spinner)findViewById(R.id.contact);

        next=(Button)findViewById(R.id.nxt);




        job_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                job_str=job_spinner.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        marital_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                marital_str=marital_spinner.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        education_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                education_str=education_spinner.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        defaultt_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                defaultt_str=defaultt_spinner.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        housing_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                housign_str=housing_spinner.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        loan_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loan_str=loan_spinner.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        contact_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                contact_str=contact_spinner.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        System.out.println("values are before nxt click "+age_str+balance_str+job_str+marital_str+education_str+defaultt_str+housign_str+loan_str+contact_str+balance_str+age_str);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                balance_str=balance.getText().toString().trim();
                age_str=age.getText().toString().trim();
                if(age_str.isEmpty() || balance_str.isEmpty()){System.out.println("age balance is empty");}
                Log.d("log 4","starting next button-----");

                //Log.d("page 1 values",job_str+marital_str+education_str+defaultt_str+housign_str+loan_str+contact_str);
                System.out.println("values in nxt click  "+job_str+marital_str+education_str+defaultt_str+housign_str+loan_str+contact_str+balance_str+age_str);
                Intent intent = new Intent(getApplicationContext(),second_page.class);
                intent.putExtra("age",age_str);
                intent.putExtra("balance",balance_str);
                intent.putExtra("job",job_str);
                intent.putExtra("marital",marital_str);
                intent.putExtra("education",education_str);
                intent.putExtra("defaultt",defaultt_str);
                intent.putExtra("housing",housign_str);
                intent.putExtra("loan",loan_str);
                intent.putExtra("contact",contact_str);
                startActivity(intent);
            }
        });
    }

}
